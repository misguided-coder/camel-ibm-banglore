package com.example.aggregator;

import org.apache.camel.Exchange;
import org.apache.camel.processor.aggregate.AggregationStrategy;

public class BookAggregationStrategy implements AggregationStrategy {

	@Override
	public Exchange aggregate(Exchange previousExchange, Exchange currentExchange) {

		if(previousExchange == null)
			return currentExchange;
		else {
			String previous = previousExchange.getIn().getBody(String.class);
			String current = currentExchange.getIn().getBody(String.class);
			previousExchange.getIn().setBody(previous+" || "+current);
			return previousExchange;
		}
	}

}
