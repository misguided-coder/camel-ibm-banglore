package com.example.aggregator;

import java.util.concurrent.TimeUnit;

import org.apache.activemq.camel.component.ActiveMQComponent;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class CamelEngine1 {

	public static void main(String[] args) throws Exception {
		new CamelEngine1();
	}

	public CamelEngine1() throws Exception {

		ActiveMQComponent activeMQComponent = new ActiveMQComponent();
		activeMQComponent.setBrokerURL("tcp://localhost:61616");
		
		CamelContext camelContext = new DefaultCamelContext();
		camelContext.addComponent("activemq", activeMQComponent);
		
		camelContext.addRoutes(new RouteBuilder() {

			@Override
			public void configure() {

				from("direct://Books")
					//Aggregator EIP
					.aggregate(header("Publisher"),new BookAggregationStrategy())
					//.completionSize(2)
					//.completionInterval(2000)
					.log("Book Detail is : ${body}");

			}

		});

		camelContext.start();
		
		ProducerTemplate producerTemplate  = camelContext.createProducerTemplate();
	
		producerTemplate.sendBodyAndHeader("direct://Books", "Java by Example", "Publisher","Packt");
		producerTemplate.sendBodyAndHeader("direct://Books", "Camel by Example", "Publisher","Manning");
		producerTemplate.sendBodyAndHeader("direct://Books", "Camel in Action", "Publisher","Manning");
		producerTemplate.sendBodyAndHeader("direct://Books", "Concurrency in  Practive", "Publisher","Packt");
		producerTemplate.sendBodyAndHeader("direct://Books", "Learn Scala", "Publisher","Manning");
		producerTemplate.sendBodyAndHeader("direct://Books", "Scala by Example", "Publisher","Packt");
		
		
		TimeUnit.SECONDS.sleep(4);

		camelContext.stop();
	}
}