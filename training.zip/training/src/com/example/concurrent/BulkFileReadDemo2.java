package com.example.concurrent;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.NotifyBuilder;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class BulkFileReadDemo2 {

	public static void main(String[] args) throws Exception {
		new BulkFileReadDemo2();
	}

	public BulkFileReadDemo2() throws Exception {
	
		CamelContext camelContext = new DefaultCamelContext();
		
		NotifyBuilder notify = new NotifyBuilder(camelContext)
				.whenDoneByIndex(0).create();
		
		camelContext.addRoutes(new RouteBuilder() {

			@Override
			public void configure() {

				//ExecutorService executorService = Executors.newFixedThreadPool(50);
				ExecutorService executorService = Executors.newCachedThreadPool();
				//ExecutorService executorService = new ThreadPoolExecutor(20, 200, 500, TimeUnit.MILLISECONDS, new SynchronousQueue<>());

				from("file://files/in?noop=true&include=orders.csv")
					.split().tokenize("\n")
					//Concurrent EIP
					.executorService(executorService)
						.process(new Processor() {
							
							@Override
							public void process(Exchange exchange) throws Exception {
								String vin = exchange.getIn().getBody(String.class).split(",")[0];
								System.out.println("Inside CarProcessor - Processing Car[ "+vin+" ] and Sold by Thread "+Thread.currentThread().getName());
								TimeUnit.MILLISECONDS.sleep(100);
							}
						});
				

			}

		});

		camelContext.start();

			long startTime = System.currentTimeMillis();
		
				notify.matches(2, TimeUnit.MINUTES); //Barrier on which listener will wait for max 2 minutes
		
			long endTime = System.currentTimeMillis();
			System.out.println("Total Time : "+(endTime-startTime)/1000+" seconds");
			
		
			System.in.read();

		camelContext.stop();
	}

}