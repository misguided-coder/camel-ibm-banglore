package com.example.concurrent;

import java.util.concurrent.TimeUnit;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class WriteFileDemo {

	public static void main(String[] args) throws Exception {
		new WriteFileDemo();
	}

	public WriteFileDemo() throws Exception {

		CamelContext camelContext = new DefaultCamelContext();
		camelContext.addRoutes(new RouteBuilder() {

			@Override
			public void configure() {

				from("direct://WRITE_FILE")
						.setHeader(Exchange.FILE_NAME).constant("orders.csv")
						//Loop EIP
						.setHeader("VIN").constant(1000)
						.loop(header("LINES"))
							.process(new Processor() {
								
								@Override
								public void process(Exchange exchange) throws Exception {
									 int vin = exchange.getIn().getHeader("VIN",Integer.class);
									 vin++;
									 exchange.getIn().setHeader("VIN",vin);
								}
							})
							.setBody().simple("${header.VIN},X1,BMW,200000.00,Black")
							.setBody(body().append("\n"))
							.to("file://files/in?FileExist=Append");
			}

		});

		camelContext.start();

		ProducerTemplate producerTemplate = camelContext.createProducerTemplate();
		producerTemplate.sendBodyAndHeader("direct://WRITE_FILE","","LINES",10000);

			TimeUnit.SECONDS.sleep(5);
			System.out.println("File Writing Done!!!!");

		camelContext.stop();
	}

}