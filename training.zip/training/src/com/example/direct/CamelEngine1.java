package com.example.direct;

import java.util.concurrent.TimeUnit;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class CamelEngine1 {
		
	public static void main(String[] args) throws Exception {
		new CamelEngine1();
	}		

	
	public CamelEngine1() throws Exception {
		
		IntegrationRoute integrationRoute = new IntegrationRoute(); 

		CamelContext camelContext = new DefaultCamelContext();
		camelContext.addRoutes(integrationRoute); 
		
		camelContext.start();
			
			ProducerTemplate producerTemplate = camelContext.createProducerTemplate();
			producerTemplate.sendBody("direct://GO","Life is cool!!");
			producerTemplate.sendBodyAndHeader("direct://GO","Life is cool!!","Author","Ritesh Tyagi");
			
			TimeUnit.SECONDS.sleep(4);
			
		camelContext.stop();
	}
		
	class IntegrationRoute extends RouteBuilder {
		
		@Override
		public void configure() {

			from("direct://GO")
				.process(new Processor() {
					
					@Override
					public void process(Exchange exchange) throws Exception {
						System.out.println("Exchange processed : "+exchange);
					}
				})
				.log("Message Logger : ${body}")
				.log("Message Logger : ${headers}");
		}

	}
	
}