package com.example.dr;

import org.apache.camel.Exchange;
import org.apache.camel.Header;

public class DynamicRouterService {

	public String pickNextRecipent(String body,@Header(Exchange.SLIP_ENDPOINT) String reciepent) {
		
		if(reciepent == null)
			return "direct://DBWorker";
		else if(reciepent.equals("direct://DBWorker"))
			return "direct://SMSWorker,direct://FileWorker";
		else if(reciepent.equals("direct://FileWorker"))
			return "direct://EmailWorker";
		else
			return null;
	}
	
}
