package com.example.exception;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;

public class CalService implements Processor {
	@Override
	public void process(Exchange exchange) throws Exception {
		Message message = exchange.getIn();
		String body = message.getBody(String.class);
		System.out.printf("Inside CalService - %s%n",body);
		int i = 10/0;
		/*int[] arr = new int[2];
		arr[0] = 1000;
		arr[1] = 2000;
		arr[2] = 3000;*/
	}
}
