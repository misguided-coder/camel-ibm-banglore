package com.example.exception;

import java.util.concurrent.TimeUnit;

import org.apache.activemq.camel.component.ActiveMQComponent;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class CamelEngine1 {

	public static void main(String[] args) throws Exception {
		new CamelEngine1();
	}

	public CamelEngine1() throws Exception {

		ActiveMQComponent activeMQComponent = new ActiveMQComponent();
		activeMQComponent.setBrokerURL("tcp://localhost:61616");
		
		CamelContext camelContext = new DefaultCamelContext();
		camelContext.addComponent("activemq", activeMQComponent);
		
		camelContext.addRoutes(new RouteBuilder() {

			@Override
			public void configure() {

				from("direct://GO").routeId("ROUTE_SPECIFIC_ERROR_HANDLER_ROUTE")
					.doTry()
						.process(new CalService())
						.process(new EmailService())
					.doCatch(ArithmeticException.class)
						.to("log:ArithmeticException Handeled!!!")
						.log("BODY : ${body}")
						.log("Exception Details : ${exception}")
						.setBody().simple("${exception}")	
						.to("activemq:ErrorQ")
					.doCatch(ArrayIndexOutOfBoundsException.class)
						.to("log:ArrayIndexOutOfBoundsException Handeled!!!")
						.log("BODY : ${body}")
						.log("Exception Details : ${exception}")
						.setBody().simple("${exception}")	
						.to("activemq:ErrorQ")
					.doFinally()	
						.log("I am the boss!!!");
			}

		});

		
		camelContext.start();
		
		ProducerTemplate producerTemplate  = camelContext.createProducerTemplate();
		
		producerTemplate.sendBody("direct://GO", "Enjoy");
		
		TimeUnit.SECONDS.sleep(4);

		camelContext.stop();
	}
}