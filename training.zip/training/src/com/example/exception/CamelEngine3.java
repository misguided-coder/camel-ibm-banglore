package com.example.exception;

import java.util.concurrent.TimeUnit;

import org.apache.activemq.camel.component.ActiveMQComponent;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class CamelEngine3 {

	public static void main(String[] args) throws Exception {
		new CamelEngine3();
	}

	public CamelEngine3() throws Exception {

		ActiveMQComponent activeMQComponent = new ActiveMQComponent();
		activeMQComponent.setBrokerURL("tcp://localhost:61616");
		
		CamelContext camelContext = new DefaultCamelContext();
		camelContext.addComponent("activemq", activeMQComponent);
		
		camelContext.addRoutes(new RouteBuilder() {

			@Override
			public void configure() {
				
				onException(ArithmeticException.class)
					.handled(true)
					.log("Exception Handeled by Common Handler : ${exception}");

				from("direct://GO_CAL").routeId("CAL_ROUTE")
					.process(new CalService());
			
				from("direct://GO_EMAIL").routeId("EMAIL_ROUTE")
					.process(new EmailService());
			}

		});

		
		camelContext.start();
		
		ProducerTemplate producerTemplate  = camelContext.createProducerTemplate();
		
		producerTemplate.sendBody("direct://GO_CAL", "Calculate 2+2");
		producerTemplate.sendBody("direct://GO_EMAIL", "Today is Friday");
		
		TimeUnit.SECONDS.sleep(4);

		camelContext.stop();
	}
}