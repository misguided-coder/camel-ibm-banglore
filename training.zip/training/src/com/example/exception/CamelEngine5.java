package com.example.exception;

import java.util.concurrent.TimeUnit;

import org.apache.activemq.camel.component.ActiveMQComponent;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class CamelEngine5 {

	public static void main(String[] args) throws Exception {
		new CamelEngine5();
	}

	public CamelEngine5() throws Exception {

		ActiveMQComponent activeMQComponent = new ActiveMQComponent();
		activeMQComponent.setBrokerURL("tcp://localhost:61616");
		
		CamelContext camelContext = new DefaultCamelContext();
		camelContext.addComponent("activemq", activeMQComponent);
		
		camelContext.addRoutes(new RouteBuilder() {

			@Override
			public void configure() {
				
				//errorHandler(noErrorHandler());
				/*errorHandler(defaultErrorHandler()
						.maximumRedeliveries(5)
						.redeliveryDelay(2000));
				*/
				
				//errorHandler(deadLetterChannel("activemq:DLQ"));
				errorHandler(
						deadLetterChannel("file://files/logs/")
						.useOriginalMessage());
			
				from("direct://GO_SMS").routeId("SMS_ROUTE")
					.process(new SMSService())
					.log("SMS are done!!!");
			}

		});
		
		camelContext.start();
		
		ProducerTemplate producerTemplate  = camelContext.createProducerTemplate();
		
			producerTemplate.sendBody("direct://GO_SMS", "$2000000 debited!");
		
		TimeUnit.SECONDS.sleep(4);

		camelContext.stop();
	}
}