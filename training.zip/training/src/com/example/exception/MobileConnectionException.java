package com.example.exception;

public class MobileConnectionException extends Exception {
	public MobileConnectionException() {
	}

	public MobileConnectionException(String message) {
		super(message);
	}

}
