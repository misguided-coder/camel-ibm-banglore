package com.example.exception;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;

public class SMSService implements Processor {
	@Override
	public void process(Exchange exchange) throws Exception {
		Message message = exchange.getIn();
		String body = message.getBody(String.class);
		System.out.printf("Inside SMSService - SMS Sent %s%n",body);
		throw new MobileConnectionException();
	}
}
