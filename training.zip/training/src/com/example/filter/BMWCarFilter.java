package com.example.filter;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;

public class BMWCarFilter implements Predicate {

	@Override
	public boolean matches(Exchange exchange) {
		String carDetails = exchange.getIn().getBody(String.class);
		if (carDetails.contains("BMW")) {
			return true;
		}
		return false;
	}

}
