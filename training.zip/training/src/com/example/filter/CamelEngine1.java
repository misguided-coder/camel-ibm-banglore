package com.example.filter;

import java.util.concurrent.TimeUnit;

import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class CamelEngine1 {
		
	public static void main(String[] args) throws Exception {
		new CamelEngine1();
	}		

	
	public CamelEngine1() throws Exception {
		
		IntegrationRoute integrationRoute = new IntegrationRoute(); 

		CamelContext camelContext = new DefaultCamelContext();
		camelContext.addRoutes(integrationRoute); 
		
		camelContext.start();
			
			TimeUnit.SECONDS.sleep(4);
			
		camelContext.stop();
	}
		
	class IntegrationRoute extends RouteBuilder {
		
		@Override
		public void configure() {

			from("file://files/in?noop=true")
				//Filter EIP
				//.filter(header("CamelFileName").contains("news"))
				//.filter(header("CamelFileLength").isGreaterThan(20))
				//.filter(body().convertToString().contains("News"))
				.filter(header("CamelFileName").endsWith(".csv"))
					.log("Message Logger : ${body}");
		}

	}
	
}