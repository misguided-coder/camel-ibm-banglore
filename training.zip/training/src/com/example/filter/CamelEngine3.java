package com.example.filter;

import java.util.concurrent.TimeUnit;

import org.apache.activemq.camel.component.ActiveMQComponent;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class CamelEngine3 {

	public static void main(String[] args) throws Exception {
		new CamelEngine3();
	}

	public CamelEngine3() throws Exception {

		ActiveMQComponent activeMQComponent = new ActiveMQComponent();
		activeMQComponent.setBrokerURL("tcp://localhost:61616");
		
	
		CamelContext camelContext = new DefaultCamelContext();
		camelContext.addComponent("activemq", activeMQComponent);
		
		camelContext.addRoutes(new RouteBuilder() {

			@Override
			public void configure() {

				from("direct://Cars")
						// Filter EIP
						.filter().method(SUVCarFilter.class)
							.log("SUV Cars Filtered")
							.to("activemq:SUVCarsQ");
			}

		});

		camelContext.start();

		ProducerTemplate producerTemplate = camelContext.createProducerTemplate();
		
		producerTemplate.sendBody("direct://Cars","A5,Audi,2000000.00,Yellow,Luxury");
		producerTemplate.sendBody("direct://Cars","A1,Audi,500000.00,Yellow,Luxury");
		producerTemplate.sendBody("direct://Cars","Q7,Audi,8000000.00,Yellow,SUV");
		producerTemplate.sendBody("direct://Cars","Q5,Audi,9000000.00,Yellow,SUV");
		producerTemplate.sendBody("direct://Cars","X1,BMW,2000000.00,Yellow,SUV");
		
		TimeUnit.SECONDS.sleep(4);

		camelContext.stop();
	}
}