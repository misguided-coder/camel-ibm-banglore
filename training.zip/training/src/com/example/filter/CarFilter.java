package com.example.filter;

import org.apache.camel.Exchange;

public class CarFilter {
	
	public boolean isLuxuryCar(Exchange exchange) {
		String carDetails = exchange.getIn().getBody(String.class);
		if(carDetails.contains("Luxury")) {
			return true;
		}
		return false;
	}
	
}
