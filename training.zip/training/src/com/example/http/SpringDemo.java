package com.example.http;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringDemo {

	public static void main(String[] args) throws Exception {
		new ClassPathXmlApplicationContext("com/example/http/appCxt.xml");
		try {
			Thread.sleep(1000 * 5);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Done!");
	}
}
