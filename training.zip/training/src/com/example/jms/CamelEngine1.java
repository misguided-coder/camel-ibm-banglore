package com.example.jms;

import java.util.concurrent.TimeUnit;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.jms.JmsComponent;
import org.apache.camel.impl.DefaultCamelContext;

public class CamelEngine1 {
		
	public static void main(String[] args) throws Exception {
		new CamelEngine1();
	}		

	
	public CamelEngine1() throws Exception {
		
		IntegrationRoute integrationRoute = new IntegrationRoute(); 

		//Camel Engine or Routing Engine
		CamelContext camelContext = new DefaultCamelContext();
		
		ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory("tcp://localhost:61616");
		
		JmsComponent jmsComponent = new JmsComponent();
		jmsComponent.setConnectionFactory(connectionFactory);

		camelContext.addComponent("jms", jmsComponent);
		
		camelContext.addRoutes(integrationRoute); 
		
		//Routing Engine is started
		camelContext.start();
			
			TimeUnit.SECONDS.sleep(4);
			
		//Routing Engine is stopped
		camelContext.stop();
	}
		
	class IntegrationRoute extends RouteBuilder {
		
		@Override
		public void configure() {

			//Route 1
			from("file://files/in?noop=true").to("jms:HelloQ");
		}

	}
	
}