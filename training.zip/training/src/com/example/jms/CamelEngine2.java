package com.example.jms;

import java.util.concurrent.TimeUnit;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.camel.component.ActiveMQComponent;
import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.jms.JmsComponent;
import org.apache.camel.impl.DefaultCamelContext;

public class CamelEngine2 {
		
	public static void main(String[] args) throws Exception {
		new CamelEngine2();
	}		

	
	public CamelEngine2() throws Exception {
		
		IntegrationRoute integrationRoute = new IntegrationRoute(); 

		//Camel Engine or Routing Engine
		CamelContext camelContext = new DefaultCamelContext();
		
		/*ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory("tcp://localhost:61616");
		ActiveMQComponent activeMQComponent = new ActiveMQComponent();
		activeMQComponent.setConnectionFactory(connectionFactory);
		*/
		
		ActiveMQComponent activeMQComponent = new ActiveMQComponent();
		activeMQComponent.setBrokerURL("tcp://localhost:61616");
		
		camelContext.addComponent("activemq", activeMQComponent);
		
		camelContext.addRoutes(integrationRoute); 
		
		//Routing Engine is started
		camelContext.start();
			
			TimeUnit.SECONDS.sleep(4);
			
		//Routing Engine is stopped
		camelContext.stop();
	}
		
	class IntegrationRoute extends RouteBuilder {
		
		@Override
		public void configure() {

			//Route 1
			from("file://files/in?noop=true").to("activemq:HelloQ");
		}

	}
	
}