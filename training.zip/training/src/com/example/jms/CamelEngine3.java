package com.example.jms;

import java.util.concurrent.TimeUnit;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.camel.component.ActiveMQComponent;
import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.jms.JmsComponent;
import org.apache.camel.impl.DefaultCamelContext;

public class CamelEngine3 {
		
	public static void main(String[] args) throws Exception {
		new CamelEngine3();
	}		

	
	public CamelEngine3() throws Exception {
		
		IntegrationRoute integrationRoute = new IntegrationRoute(); 

		CamelContext camelContext = new DefaultCamelContext();
		
		ActiveMQComponent activeMQComponent = new ActiveMQComponent();
		activeMQComponent.setBrokerURL("tcp://localhost:61616");
		
		camelContext.addComponent("activemq", activeMQComponent);
		
		camelContext.addRoutes(integrationRoute); 
		
		camelContext.start();
			
			TimeUnit.SECONDS.sleep(4);
			
		camelContext.stop();
	}
		
	class IntegrationRoute extends RouteBuilder {
		
		@Override
		public void configure() {

			//Route 1
			from("file://files/in?noop=true").routeId("FILE_READ_ROUTE")
				.to("activemq:HelloQ");
			
			//Route 2
			from("activemq:HelloQ").routeId("JMS_READ_ROUTE")
				.log("Message Received : ${body}")
				.log("Message Received : ${header.JMSPriority}")
				.log("Message Received : ${header.CamelFileName}");
			
		}

	}
	
}