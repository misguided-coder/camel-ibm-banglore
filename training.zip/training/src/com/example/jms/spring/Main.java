package com.example.jms.spring;

import java.util.concurrent.TimeUnit;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) throws Exception {

		// IoC Container is started
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(
				"com/example/jms/spring/appCxt.xml");

		TimeUnit.SECONDS.sleep(2);

		// IoC Container is stopped
		applicationContext.destroy();
	}

}
