package com.example.router;

import java.util.concurrent.TimeUnit;

import org.apache.activemq.camel.component.ActiveMQComponent;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class CamelEngine1 {

	public static void main(String[] args) throws Exception {
		new CamelEngine1();
	}

	public CamelEngine1() throws Exception {

		ActiveMQComponent activeMQComponent = new ActiveMQComponent();
		activeMQComponent.setBrokerURL("tcp://localhost:61616");
		
	
		CamelContext camelContext = new DefaultCamelContext();
		camelContext.addComponent("activemq", activeMQComponent);
		
		camelContext.addRoutes(new RouteBuilder() {

			@Override
			public void configure() {

				from("file://files/in/cars?noop=true")
					.log("Content based routing started!!! ${body}")
					//Router EIP
					.choice()
						.when(xpath("/car/category[@type = 'Luxury']"))
							.to("activemq:LuxuryCarsQ")
							.log("LuxuryCars processed!!!!")
						.when(xpath("/car/category[@type = 'SUV']"))
							.to("activemq:SUVCarsQ")
							.log("SUVCars processed!!!!")
						.otherwise()
							.to("activemq:OtherCarsQ")
							.log("All Other Cars processed!!!!");
			}

		});

		camelContext.start();

		TimeUnit.SECONDS.sleep(4);

		camelContext.stop();
	}
}