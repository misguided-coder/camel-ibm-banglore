package com.example.router;

import java.util.concurrent.TimeUnit;

import org.apache.activemq.camel.component.ActiveMQComponent;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class CamelEngine2 {

	public static void main(String[] args) throws Exception {
		new CamelEngine2();
	}

	public CamelEngine2() throws Exception {

		ActiveMQComponent activeMQComponent = new ActiveMQComponent();
		activeMQComponent.setBrokerURL("tcp://localhost:61616");
		
	
		CamelContext camelContext = new DefaultCamelContext();
		camelContext.addComponent("activemq", activeMQComponent);
		
		camelContext.addRoutes(new RouteBuilder() {

			@Override
			public void configure() {

				from("direct://Couriers")
					//Router EIP (Header)
					.choice()
						.when(header("City").isEqualTo("Pune"))
							.bean(CourierProcessor.class, "processCourier")
							.to("activemq:PuneCityQ")
							.log("Pune Couriers processed!!!!")
						.when(header("City").isEqualTo("Bangalore"))
							.bean(CourierProcessor.class, "processCourier")
							.to("activemq:BangaloreCityQ")
							.log("Bangalore Couriers processed!!!!")
						.otherwise()
							.bean(CourierProcessor.class, "processCourier")
							.to("activemq:OtherCityQ")
							.log("All City Couriers processed!!!!");
					
			}

		});

		camelContext.start();
		
		ProducerTemplate producerTemplate = camelContext.createProducerTemplate();
		producerTemplate.sendBodyAndHeader("direct://Couriers", "Biscuit Parcels", "City","Pune");
		producerTemplate.sendBodyAndHeader("direct://Couriers", "Chocolate Parcels", "City","Pune");
		producerTemplate.sendBodyAndHeader("direct://Couriers", "Toffee Parcels", "City","Pune");
		producerTemplate.sendBodyAndHeader("direct://Couriers", "Laptop Parcels", "City","Bangalore");
		producerTemplate.sendBodyAndHeader("direct://Couriers", "Letter Parcels", "City","Delhi");
		
		
		TimeUnit.SECONDS.sleep(4);

		camelContext.stop();
	}
}