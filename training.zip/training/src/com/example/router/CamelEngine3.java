package com.example.router;

import java.util.concurrent.TimeUnit;

import org.apache.activemq.camel.component.ActiveMQComponent;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class CamelEngine3 {

	public static void main(String[] args) throws Exception {
		new CamelEngine3();
	}

	public CamelEngine3() throws Exception {

		ActiveMQComponent activeMQComponent = new ActiveMQComponent();
		activeMQComponent.setBrokerURL("tcp://localhost:61616");
		
	
		CamelContext camelContext = new DefaultCamelContext();
		camelContext.addComponent("activemq", activeMQComponent);
		
		camelContext.addRoutes(new RouteBuilder() {

			@Override
			public void configure() {

				//Main Flow
				from("direct://Couriers")
					//Router EIP (Header)
					.choice()
						.when(header("City").isEqualTo("Pune"))
							.to("direct://PuneCouriers") //Sub Flow 1
						.when(header("City").isEqualTo("Bangalore"))
							.to("direct://BangaloreCouriers") //Sub Flow 2
						.otherwise()
							.to("direct://OtherCouriers"); //Sub Flow 3
					
			
				from("direct://PuneCouriers")
					.bean(CourierProcessor.class, "processCourier")
					.to("activemq:PuneCityQ")
					.log("Pune Couriers processed!!!!");
	
				from("direct://BangaloreCouriers")
					.bean(CourierProcessor.class, "processCourier")
					.to("activemq:BangaloreCityQ")
					.log("Bangalore Couriers processed!!!!");

				from("direct://OtherCouriers")
					.bean(CourierProcessor.class, "processCourier")
					.to("activemq:OtherCityQ")
					.log("All City Couriers processed!!!!");

			}

		});

		camelContext.start();
		
		ProducerTemplate producerTemplate = camelContext.createProducerTemplate();
		producerTemplate.sendBodyAndHeader("direct://Couriers", "Biscuit Parcels", "City","Pune");
		producerTemplate.sendBodyAndHeader("direct://Couriers", "Chocolate Parcels", "City","Pune");
		producerTemplate.sendBodyAndHeader("direct://Couriers", "Toffee Parcels", "City","Pune");
		producerTemplate.sendBodyAndHeader("direct://Couriers", "Laptop Parcels", "City","Bangalore");
		producerTemplate.sendBodyAndHeader("direct://Couriers", "Letter Parcels", "City","Delhi");
		
		
		TimeUnit.SECONDS.sleep(4);

		camelContext.stop();
	}
}