package com.example.router;

import org.apache.camel.Exchange;

public class CourierProcessor {
	
	public void processCourier(Exchange exchange) {
		//SMS Logic
		//DB Logic
		String body = exchange.getIn().getBody(String.class);
		body = body + " Delivered!";
		exchange.getIn().setBody(body);
	}
		
}
