package com.example.simple;

import org.apache.camel.CamelContext;
import org.apache.camel.impl.DefaultCamelContext;

public class CamelEngine {
		
	public static void main(String[] args) throws Exception {
		
		FileIntegrationRoute integrationRoute = new FileIntegrationRoute(); 

		//Camel Engine or Routing Engine
		CamelContext camelContext = new DefaultCamelContext();
		camelContext.addRoutes(integrationRoute); 

		//Routing Engine is started
		camelContext.start();
			
			System.in.read();
			
		//Routing Engine is stopped
		camelContext.stop();

	}		
	
}