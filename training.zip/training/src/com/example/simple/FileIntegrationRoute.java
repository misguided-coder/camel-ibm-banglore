package com.example.simple;

import org.apache.camel.builder.RouteBuilder;

public class FileIntegrationRoute extends RouteBuilder {

	@Override
	public void configure() {

		//Route 1
		from("file://files/in?noop=true").to("file://files/out");
	}

}