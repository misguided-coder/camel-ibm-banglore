package com.example.simple.processor;

import java.util.concurrent.TimeUnit;

import org.apache.camel.CamelContext;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.util.jndi.JndiContext;

public class CamelEngine {
		
	public static void main(String[] args) throws Exception {
				
		JndiContext jndiContext = new JndiContext();
		jndiContext.bind("dataProcessor", new DataProcessor());
		
		FileIntegrationRoute integrationRoute = new FileIntegrationRoute(); 
		
		//Camel Engine or Routing Engine
		CamelContext camelContext = new DefaultCamelContext(jndiContext);
		camelContext.addRoutes(integrationRoute); 
		
		
		//Routing Engine is started
		camelContext.start();
			
		TimeUnit.SECONDS.sleep(2);
			
		//Routing Engine is stopped
		camelContext.stop();

	}		
	
}