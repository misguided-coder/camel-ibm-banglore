package com.example.simple.processor;

import java.util.Date;
import java.util.Map;

import org.apache.camel.Header;
import org.apache.camel.Headers;

public class DataProcessor {

	public void processMessage(String body) throws Exception {
		System.out.println(
				"Inside DataProcessor.processMessage() - Message " + body + " processing done at " + new Date());
	}
	
	public void process(String body, @Header("CamelFileLength") String arg, @Headers Map<String, Object> map) throws Exception {
		System.out.println("Inside DataProcessor.process() - Message " + body + " processing done at " + new Date());
		System.out.println("Inside DataProcessor.process() - " + arg);
		System.out.println("Inside DataProcessor.process() - " + map);
	}
}