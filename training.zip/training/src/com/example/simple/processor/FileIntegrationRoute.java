package com.example.simple.processor;

import org.apache.camel.builder.RouteBuilder;

public class FileIntegrationRoute extends RouteBuilder {

	@Override
	public void configure() {

		// Route 1
		from("file://files/in?noop=true") // From Endpoint
				.process(new MessageProcessor()) // Processor Endpoint
				//.bean(new LogProcessor()) // Processor Endpoint
				.bean(LogProcessor.class,"process") // Processor Endpoint
				.to("file://files/out") // To Endpoint
				.log("Message processing done by pipeline!!!!") // Log Endpoint
				//.bean(DataProcessor.class) // Processor Endpoint
				.bean(DataProcessor.class,"process") // Processor Endpoint
				.to("bean:dataProcessor?method=processMessage") // Processor Endpoint
				.to("log:Message processing done by pipeline!!!!"); // Log Endpoint
		
	}

}