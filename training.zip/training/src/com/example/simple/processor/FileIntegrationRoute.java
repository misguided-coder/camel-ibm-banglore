package com.example.simple.processor;

import org.apache.camel.builder.RouteBuilder;

public class FileIntegrationRoute extends RouteBuilder {

	@Override
	public void configure() {

		//Route 1
		from("file://files/in?noop=true")
			.process(new MessageProcessor())
				.to("file://files/out")
					.log("${headers}");
			
	}

}