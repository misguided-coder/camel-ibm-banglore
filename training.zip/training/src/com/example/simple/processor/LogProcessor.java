package com.example.simple.processor;

import java.util.Date;

import org.apache.camel.Exchange;

public class LogProcessor {

	//public void process(Exchange exchange) throws Exception {
	public void processMessage(Exchange exchange) throws Exception {
		System.out.println("Inside LogProcessor.processMessage() - Message processing done at "+new Date());
	}

	public void process(Exchange exchange) throws Exception {
		System.out.println("Inside LogProcessor.process(Exchange) - Message processing done at "+new Date()+"  BODY Content is : "+exchange.getIn().getBody(String.class));
	}

	public void process(String body) throws Exception {
		System.out.println("Inside LogProcessor.process(String) - Message processing done at "+new Date()+"  BODY Content is : "+body);
	}
}
