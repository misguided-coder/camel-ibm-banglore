package com.example.simple.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;

public class MessageProcessor implements Processor{

	@Override
	public void process(Exchange exchange) throws Exception {
		System.out.println("Inside MessageProcessor!!!!!!!");
		Message message = exchange.getIn();
		System.out.println(message.getBody(String.class));
		System.out.println(message.getHeader("CamelFileName"));
		System.out.println(message.getHeaders());
		message.setHeader("CamelFileName","fun.txt");
		message.setBody("Holidays are highly required.");
	}

}
