package com.example.splitter;

import java.util.concurrent.TimeUnit;

import org.apache.activemq.camel.component.ActiveMQComponent;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class CamelEngine1 {

	public static void main(String[] args) throws Exception {
		new CamelEngine1();
	}

	public CamelEngine1() throws Exception {

		ActiveMQComponent activeMQComponent = new ActiveMQComponent();
		activeMQComponent.setBrokerURL("tcp://localhost:61616");
		
		CamelContext camelContext = new DefaultCamelContext();
		camelContext.addComponent("activemq", activeMQComponent);
		
		camelContext.addRoutes(new RouteBuilder() {

			@Override
			public void configure() {

				from("file://files/in?noop=true")
					//Filter EIP
					.filter(header(Exchange.FILE_NAME).isEqualTo("cricket.txt"))
					//Splitter EIP
					.split().tokenize("\n")
					.process(new Processor() {
						
						@Override
						public void process(Exchange exchange) throws Exception {
							exchange.getIn().setBody(exchange.getIn().getBody(String.class).toUpperCase());
						}
					})	
					.log("Message Processed : ${body}");
					
				
			}

		});

		camelContext.start();
		
		TimeUnit.SECONDS.sleep(4);

		camelContext.stop();
	}
}