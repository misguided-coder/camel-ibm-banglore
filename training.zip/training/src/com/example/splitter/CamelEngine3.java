package com.example.splitter;

import java.util.concurrent.TimeUnit;

import org.apache.activemq.camel.component.ActiveMQComponent;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class CamelEngine3 {

	public static void main(String[] args) throws Exception {
		new CamelEngine3();
	}

	public CamelEngine3() throws Exception {

		ActiveMQComponent activeMQComponent = new ActiveMQComponent();
		activeMQComponent.setBrokerURL("tcp://localhost:61616");
		
		CamelContext camelContext = new DefaultCamelContext();
		camelContext.addComponent("activemq", activeMQComponent);
		
		camelContext.addRoutes(new RouteBuilder() {

			@Override
			public void configure() {

				from("file://files/in?noop=true")
					//Filter EIP
					.filter(header(Exchange.FILE_NAME).isEqualTo("cars.csv"))
					//Splitter EIP
					.split().tokenize("\n")
					.to("activemq:CarsQ");
					
				from("activemq:CarsQ")
					.pipeline()
						.process(new Processor() {
							
							double total = 0.0;
							
							@Override
							public void process(Exchange exchange) throws Exception {
								Message message = exchange.getIn();
								String car = message.getBody(String.class);
								double price = Double.parseDouble(car.split(",")[3]);
								total = total + price;
								message.setHeader("TOTAL_PRICE", total);
							}
						})
						.log("Car Sold!")
					.end()
					.log("All Cars will be sold in  : ${header.TOTAL_PRICE}");
				
			}

		});

		camelContext.start();
		
		TimeUnit.SECONDS.sleep(4);

		camelContext.stop();
	}
}