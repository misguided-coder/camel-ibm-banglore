package com.example.splitter;

import java.util.concurrent.TimeUnit;

import org.apache.activemq.camel.component.ActiveMQComponent;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class CamelEngine4 {

	public static void main(String[] args) throws Exception {
		new CamelEngine4();
	}

	public CamelEngine4() throws Exception {

		ActiveMQComponent activeMQComponent = new ActiveMQComponent();
		activeMQComponent.setBrokerURL("tcp://localhost:61616");
		
		CamelContext camelContext = new DefaultCamelContext();
		camelContext.addComponent("activemq", activeMQComponent);
		
		camelContext.addRoutes(new RouteBuilder() {

			@Override
			public void configure() {

				from("file://files/in?noop=true&include=cars.xml")
					//Splitter EIP
					.split(xpath("cars/category"))
						.to("activemq:CarsQ");
				
				from("activemq:CarsQ")
					.choice()
						.when(xpath("category[@type = 'Luxury']"))
							.to("activemq:LuxuryCars")
						.when(xpath("category[@type = 'SUV']"))
							.to("activemq:SUVCars")
						.when(xpath("category[@type = 'Sedan']"))
							.to("activemq:SedanCars")
						.otherwise()
							.to("activemq:OtherCars");
	
				
			
			}

		});

		camelContext.start();
		
		TimeUnit.SECONDS.sleep(4);

		camelContext.stop();
	}
}