package com.example.splitter;

import java.util.concurrent.TimeUnit;

import org.apache.activemq.camel.component.ActiveMQComponent;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class CamelEngine5 {

	public static void main(String[] args) throws Exception {
		new CamelEngine5();
	}

	public CamelEngine5() throws Exception {

		ActiveMQComponent activeMQComponent = new ActiveMQComponent();
		activeMQComponent.setBrokerURL("tcp://localhost:61616");
		
		CamelContext camelContext = new DefaultCamelContext();
		camelContext.addComponent("activemq", activeMQComponent);
		
		camelContext.addRoutes(new RouteBuilder() {

			@Override
			public void configure() {

				from("file://files/in?noop=true&include=cars.xml")
					//Splitter EIP
					.split(xpath("cars/category"))
						.to("activemq:CarsQ");
				
				from("activemq:CarsQ")
					.choice()
						.when(xpath("category[@type = 'Luxury']"))
							.to("direct://Luxury")
						.when(xpath("category[@type = 'SUV']"))
							.to("direct://SUV")
						.when(xpath("category[@type = 'Sedan']"))
							.to("direct://Sedan")
						.otherwise()
							.to("direct://Others");
	
				from("direct://Luxury")
					.split(xpath("category/car"))
					.to("activemq:LuxuryCars");

				from("direct://SUV")
					.split(xpath("category/car"))
					.to("activemq:SUVCars");

				from("direct://Sedan")
					.split(xpath("category/car"))
					.to("activemq:SedanCars");

				from("direct://Others")
					.split(xpath("category/car"))
					.to("activemq:OtherCars");

			}

		});

		camelContext.start();
		
		TimeUnit.SECONDS.sleep(4);

		camelContext.stop();
	}
}