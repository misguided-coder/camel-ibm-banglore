package com.example.spring.dsl;

import java.util.concurrent.TimeUnit;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) throws Exception {
		
		//IoC Container is started
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext("com/example/spring/dsl/appCxt.xml");
		
		TimeUnit.SECONDS.sleep(2);
						
		//IoC Container is stopped
		applicationContext.destroy();
	}
	
}
