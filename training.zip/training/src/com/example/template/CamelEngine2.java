package com.example.template;

import java.util.concurrent.TimeUnit;

import org.apache.activemq.camel.component.ActiveMQComponent;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class CamelEngine2 {

	public static void main(String[] args) throws Exception {
		new CamelEngine2();
	}

	public CamelEngine2() throws Exception {

		ActiveMQComponent activeMQComponent = new ActiveMQComponent();
		activeMQComponent.setBrokerURL("tcp://localhost:61616");

		IntegrationRoute integrationRoute = new IntegrationRoute();

		CamelContext camelContext = new DefaultCamelContext();
		camelContext.addComponent("activemq", activeMQComponent);
		camelContext.addRoutes(integrationRoute);

		camelContext.start();

		ProducerTemplate producerTemplate = camelContext.createProducerTemplate();
		producerTemplate.sendBody("activemq:OrderQ", "Five Audi Only");

		TimeUnit.SECONDS.sleep(20);

		camelContext.stop();
	}

	class IntegrationRoute extends RouteBuilder {

		@Override
		public void configure() {

			from("activemq:OrderQ")
				.process(new Processor() {

					@Override
					public void process(Exchange exchange) throws Exception {
						System.out.println("Exchange processed : " + exchange);
					}
				})
				.log("Message Logger : ${body}").log("Message Logger : ${headers}");

		}

	}

}