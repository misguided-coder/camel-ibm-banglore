package com.example.timer;

import java.util.concurrent.TimeUnit;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class CamelEngine1 {
		
	public static void main(String[] args) throws Exception {
		new CamelEngine1();
	}		

	
	public CamelEngine1() throws Exception {
		
		IntegrationRoute integrationRoute = new IntegrationRoute(); 

		CamelContext camelContext = new DefaultCamelContext();
		camelContext.addRoutes(integrationRoute); 
		
		camelContext.start();
			
			System.in.read();
			
		camelContext.stop();
	}
		
	class IntegrationRoute extends RouteBuilder {
		
		@Override
		public void configure() {

			from("timer://TickClock?period=2s")
				.process(new Processor() {
					
					@Override
					public void process(Exchange exchange) throws Exception {
						exchange.getIn().setBody("Life is very cool.");
					}
				})
				.log("Message Logger : ${body}");
		}

	}
	
}