package com.example.timer;

import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class CamelEngine2 {
		
	public static void main(String[] args) throws Exception {
		new CamelEngine2();
	}		

	
	public CamelEngine2() throws Exception {
		
		IntegrationRoute integrationRoute = new IntegrationRoute(); 

		CamelContext camelContext = new DefaultCamelContext();
		camelContext.addRoutes(integrationRoute); 
		
		camelContext.start();
			
			System.in.read();
			
		camelContext.stop();
	}
		
	class IntegrationRoute extends RouteBuilder {
		
		@Override
		public void configure() {

			from("timer://TickClock?period=2s")
				//.setBody().constant("Life is fun")
				.setBody().simple("Message produced at : ${header.firedTime}")
				.setHeader("City").constant("Bangalore")
				.log("Message Logger : ${body} plus headers ${headers}");
		}

	}
	
}