package com.example.transform;

import java.util.concurrent.TimeUnit;

import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class TransformDemo1 {

	public static void main(String[] args) throws Exception {
		new TransformDemo1();
	}

	public TransformDemo1() throws Exception {
	
		CamelContext camelContext = new DefaultCamelContext();
		
		camelContext.addRoutes(new RouteBuilder() {

			@Override
			public void configure() {

				from("direct://GO")
					//Transform EIP
					//.transform().constant("Life is fun!!")
					.transform().simple("Life is fun at ${date:now:HH:mm:ss}")
					.to("stream:out");
				

			}

		});

		camelContext.start();
		
			ProducerTemplate producerTemplate = camelContext.createProducerTemplate();
			producerTemplate.sendBody("direct://GO","Life is cool!!");
			
			TimeUnit.SECONDS.sleep(2);

		camelContext.stop();
	}

}