package com.example.transform;

import java.util.concurrent.TimeUnit;

import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class TransformDemo2 {

	public static void main(String[] args) throws Exception {
		new TransformDemo2();
	}

	public TransformDemo2() throws Exception {
	
		CamelContext camelContext = new DefaultCamelContext();
		
		camelContext.addRoutes(new RouteBuilder() {

			@Override
			public void configure() {

				from("direct://GO")
					//Transform EIP
					.transform().method(TransformerBean.class,"upperCase")
					.transform().method(TransformerBean.class,"customize")
					.to("stream:out");
				

			}

		});

		camelContext.start();
		
			ProducerTemplate producerTemplate = camelContext.createProducerTemplate();
			producerTemplate.sendBody("direct://GO","Life is cool!!");
			
			TimeUnit.SECONDS.sleep(2);

		camelContext.stop();
	}

}