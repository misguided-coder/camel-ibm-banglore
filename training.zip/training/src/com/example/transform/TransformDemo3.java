package com.example.transform;

import java.util.concurrent.TimeUnit;

import javax.xml.bind.JAXBContext;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.converter.jaxb.JaxbDataFormat;
import org.apache.camel.impl.DefaultCamelContext;

public class TransformDemo3 {

	public static void main(String[] args) throws Exception {
		new TransformDemo3();
	}

	public TransformDemo3() throws Exception {
		
		JAXBContext jaxbContext = JAXBContext.newInstance(Car.class);
		
		JaxbDataFormat jaxbDataFormat = new JaxbDataFormat(jaxbContext); 
		
		
		CamelContext camelContext = new DefaultCamelContext();
		
		camelContext.addRoutes(new RouteBuilder() {

			@Override
			public void configure() {				
				from("file://files/in/cars?noop=true&include=car.xml")
					.unmarshal(jaxbDataFormat)
					.process(new Processor() {
						
						@Override
						public void process(Exchange exchange) throws Exception {
							Car car = exchange.getIn().getBody(Car.class);	
							System.out.println(car);
							System.out.println(car.getVin());
							System.out.println(car.getModel());
							System.out.println(car.getMake());
							System.out.println(car.getPrice());
							System.out.println(car.getColor());
							car.setPrice(400000.00);
							car.setColor("Yellow");
						}
					})
					.marshal(jaxbDataFormat)
					.to("stream:out");
				

			}

		});

		camelContext.start();
		
			
			TimeUnit.SECONDS.sleep(2);

		camelContext.stop();
	}

}