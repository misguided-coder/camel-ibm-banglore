package com.example.transform;

import java.util.concurrent.TimeUnit;

import javax.xml.bind.JAXBContext;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.jackson.JacksonDataFormat;
import org.apache.camel.converter.jaxb.JaxbDataFormat;
import org.apache.camel.impl.DefaultCamelContext;

public class TransformDemo5 {

	public static void main(String[] args) throws Exception {
		new TransformDemo5();
	}

	public TransformDemo5() throws Exception {
		
		
		JacksonDataFormat jacksonDataFormat = new JacksonDataFormat(Car.class);
		
		CamelContext camelContext = new DefaultCamelContext();
		
		camelContext.addRoutes(new RouteBuilder() {

			@Override
			public void configure() {				
				from("file://files/in/cars?noop=true&include=car.json")
					.unmarshal(jacksonDataFormat)
					.process(new Processor() {
						
						@Override
						public void process(Exchange exchange) throws Exception {
							Car car = exchange.getIn().getBody(Car.class);	
							System.out.println(car);
							System.out.println(car.getVin());
							System.out.println(car.getModel());
							System.out.println(car.getMake());
							System.out.println(car.getPrice());
							System.out.println(car.getColor());
						}
					});
			}

		});

		camelContext.start();
		
			
			TimeUnit.SECONDS.sleep(2);

		camelContext.stop();
	}

}