package com.example.transform;

import org.apache.camel.Exchange;

public class TransformerBean {

	public String upperCase(Exchange exchange) {
		System.out.println("Inside TransformerBean.upperCase()!!!");	
		return exchange.getIn().getBody(String.class).toUpperCase();
	}

	public String customize(Exchange exchange) {
		System.out.println("Inside TransformerBean.customize()!!!");	
		String body =exchange.getIn().getBody(String.class);
		StringBuilder stringBuilder = new StringBuilder();
		String[] arr = body.split(" ");
		for(String value : arr) {
			stringBuilder.append(value);
			stringBuilder.append(" | ");
		}
		return stringBuilder.toString();
	}

}
