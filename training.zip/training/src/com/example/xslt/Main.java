package com.example.xslt;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

public class Main {

	public static void main(String[] args) throws Exception {
		new Main();

	}

	public Main() throws Exception {

		CamelContext context = new DefaultCamelContext();
		context.setTracing(true);

		context.addRoutes(new DynamicRouterBuilder());
		context.start();

		System.in.read();

		context.stop();
		System.out.println("Done!");

	}

	class DynamicRouterBuilder extends RouteBuilder {

		public void configure() throws Exception {

			from("file://C:/camel-ibm-workspace/training/data?noop=true&include=employee.xml")
					.to("stream:out")
					.to("xslt:C:/camel-ibm-workspace/training/data/employee.xsl")
					.to("stream:out");
		}
	}

}
